#!/usr/bin/env node
import { join } from "node:path";
import { startProdServer } from "vinext/server/prod-server";

const portValue=process.env.PORT || "3000";
const port=portValue.startsWith("/")?portValue:Number.parseInt(portValue,10);
if(typeof port==="number"&&(!Number.isInteger(port)||port<0||port>65535))throw Error("Invalid listen port");
const host = process.env.HOST ?? "0.0.0.0";

startProdServer({
  port,
  host,
  outDir: join(import.meta.dirname, "dist"),
}).catch((error) => {
  console.error("[vinext] Failed to start standalone server");
  console.error(error);
  process.exit(1);
});
